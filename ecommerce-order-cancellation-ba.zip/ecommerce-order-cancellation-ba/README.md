# Reducing stock-related order cancellations in an e-commerce marketplace

**Business Analyst portfolio case study | Synthetic data | Proposed design**

A marketplace can accept an order even when its seller cannot fulfil it. This project measures cancellations across the order lifecycle, isolates stock-related failures, and specifies an inventory reservation control with acceptance criteria and UAT.

![Demo dashboard showing 1,000 orders, 120 cancellations and 60 stock-related cancellations](assets/demo-analysis.png)

## Executive summary

Of 1,000 synthetic placed orders, 120 cancel. Stock-related reasons account for 60 cancellations, equivalent to **6.0% of placed orders** and **50.0% of cancellations**. Within those 60, 30 are tagged stale stock, 20 concurrent oversell, and 10 physical mismatch. These counts were designed into the fixture to demonstrate the analysis. Production evidence would be required to establish cause and prevalence.

The proposed MVP reserves stock at checkout, converts the hold into an allocation after placement, and releases or reconciles the hold on failure. The illustrative pilot target is **≤4.0% stock-related cancellations** from a comparable 6.0% baseline, with checkout conversion and payment exceptions monitored alongside it.

## Repository map

| File | Contents |
|---|---|
| README.md | Executive summary, image, repository map and reproduction steps |
| [docs/01-problem-statement.md](docs/01-problem-statement.md) | Problem, objective, scope and constraints |
| [docs/02-stakeholders-and-discovery.md](docs/02-stakeholders-and-discovery.md) | Stakeholder register, RACI and discovery plan |
| [docs/03-process-maps.md](docs/03-process-maps.md) | Current and proposed workflows, handoffs and gaps |
| [docs/04-root-cause-analysis.md](docs/04-root-cause-analysis.md) | Cancellation taxonomy, fishbone categories, 5 Whys and evidence plan |
| [docs/05-business-requirements.md](docs/05-business-requirements.md) | BRD with outcomes and business requirements |
| [docs/06-functional-specification.md](docs/06-functional-specification.md) | FRD/SRS with rules, state transitions and NFRs |
| [docs/07-product-backlog.md](docs/07-product-backlog.md) | Prioritized user stories and acceptance criteria |
| [docs/08-uat-and-traceability.md](docs/08-uat-and-traceability.md) | UAT steps, expected results and requirement coverage |
| [docs/09-business-case-and-rollout.md](docs/09-business-case-and-rollout.md) | Options, illustrative ROI, rollout, risks and rollback |
| [docs/10-analysis-findings.md](docs/10-analysis-findings.md) | KPI calculations, interpretation and validation plan |
| [data/data-dictionary.md](data/data-dictionary.md) | Data grain, fields, assumptions and quality checks |
| [data/orders.csv](data/orders.csv) | 1,000 synthetic order records |
| [analysis/kpis.sql](analysis/kpis.sql) | SQLite queries for totals, reasons, stages and weekly rates |
| [analysis/build_demo.py](analysis/build_demo.py) | Recreates the data, runs SQL checks and renders the image |
| [assets/demo-analysis.png](assets/demo-analysis.png) | Demo dashboard with KPIs, causes, stages and stock hypotheses |

## Reproduce

From the repository root, install matplotlib with `python -m pip install matplotlib`, then run `python analysis/build_demo.py`. The script uses Python's built-in SQLite module and prints query results. The dataset and visual can also be reviewed directly without running code.

## Portfolio use

Suggested GitHub name: `ecommerce-order-cancellation-ba`. Extract the ZIP and commit the contents of its top-level folder so this README appears at the repository root.

Suggested résumé bullet: **Designed a marketplace checkout and inventory reservation workflow to address stock-related order cancellations, using SQL analysis, process maps, requirements, and traceable UAT scenarios.**

Project status: portfolio design and reproducible analysis. Stakeholder interviews, software delivery, pilot results and UAT execution are proposed.
