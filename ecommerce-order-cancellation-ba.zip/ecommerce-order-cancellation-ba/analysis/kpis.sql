SELECT COUNT(*) AS placed,
       SUM(status = 'CANCELLED') AS cancelled,
       SUM(cancellation_reason = 'Stock unavailable') AS stock_cancelled,
       ROUND(100.0 * AVG(status = 'CANCELLED'), 1) AS cancellation_pct,
       ROUND(100.0 * AVG(cancellation_reason = 'Stock unavailable'), 1) AS stock_cancellation_pct,
       ROUND(100.0 * SUM(cancellation_reason = 'Stock unavailable')
             / NULLIF(SUM(status = 'CANCELLED'), 0), 1) AS stock_share_pct
FROM orders;

SELECT cancellation_reason, COUNT(*) AS cancellations
FROM orders
WHERE status = 'CANCELLED'
GROUP BY cancellation_reason
ORDER BY cancellations DESC, cancellation_reason;

SELECT detection_stage, COUNT(*) AS cancellations
FROM orders
WHERE status = 'CANCELLED'
GROUP BY detection_stage
ORDER BY cancellations DESC, detection_stage;

SELECT stock_driver, COUNT(*) AS cancellations
FROM orders
WHERE cancellation_reason = 'Stock unavailable'
GROUP BY stock_driver
ORDER BY cancellations DESC, stock_driver;

SELECT cohort_week, COUNT(*) AS placed, SUM(status = 'CANCELLED') AS cancelled,
       ROUND(100.0 * AVG(cancellation_reason = 'Stock unavailable'), 1) AS stock_cancellation_pct
FROM orders
GROUP BY cohort_week
ORDER BY cohort_week;
