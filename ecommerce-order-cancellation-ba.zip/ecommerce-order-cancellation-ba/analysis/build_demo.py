"""Rebuild the synthetic fixture, run KPI SQL and render the demo dashboard."""
import csv
import random
import sqlite3
from datetime import date, timedelta
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
FIELDS = (
    "order_id", "placed_date", "cohort_week", "seller_id", "category",
    "payment_method", "order_value_inr", "status", "cancellation_reason",
    "detection_stage", "stock_driver",
)
EVENTS = (
    ("Stock unavailable", "Seller confirmation", "Stale stock", 30),
    ("Stock unavailable", "Seller confirmation", "Concurrent oversell", 20),
    ("Stock unavailable", "Picking", "Physical mismatch", 10),
    ("Customer request", "Pre-dispatch", "", 20),
    ("Payment exception", "Payment reconciliation", "", 15),
    ("Delivery exception", "Pre-dispatch", "", 10),
    ("Seller processing", "Seller confirmation", "", 8),
    ("Platform error", "Payment reconciliation", "", 5),
    ("Unknown", "Pre-dispatch", "", 2),
)


def build_orders():
    rng = random.Random(42)
    cancellations = [(reason, stage, driver)
                     for reason, stage, driver, count in EVENTS
                     for _ in range(count)]
    rng.shuffle(cancellations)
    buckets = [cancellations[offset::4] for offset in range(4)]
    rows = []
    for week, bucket in enumerate(buckets, start=1):
        outcomes = bucket + [("", "", "")] * (250 - len(bucket))
        rng.shuffle(outcomes)
        for position, (reason, stage, driver) in enumerate(outcomes):
            day = date(2026, 1, 5) + timedelta(days=(week - 1) * 7 + position * 7 // 250)
            payment = "PREPAID" if reason == "Payment exception" else rng.choice(("PREPAID", "COD"))
            rows.append((
                f"ORD-{len(rows) + 1:04}", day.isoformat(), week,
                f"S{rng.randrange(1, 11):02}", rng.choice(("Grocery", "Home", "Fashion", "Electronics")),
                payment, rng.randrange(199, 3000), "CANCELLED" if reason else "COMPLETED",
                reason, stage, driver,
            ))
    return rows


def run_analysis(rows):
    column_types = ["TEXT PRIMARY KEY", "TEXT", "INTEGER", "TEXT", "TEXT",
                    "TEXT", "INTEGER", "TEXT", "TEXT", "TEXT", "TEXT"]
    schema = ", ".join(f"{name} {kind}" for name, kind in zip(FIELDS, column_types))
    with sqlite3.connect(":memory:") as db:
        db.execute(f"CREATE TABLE orders ({schema})")
        placeholders = ", ".join("?" for _ in FIELDS)
        db.executemany(f"INSERT INTO orders VALUES ({placeholders})", rows)
        invalid = db.execute("""
            SELECT COUNT(*) FROM orders
            WHERE (status = 'CANCELLED' AND (cancellation_reason = '' OR detection_stage = ''))
               OR (status = 'COMPLETED' AND (cancellation_reason <> '' OR detection_stage <> ''))
               OR ((cancellation_reason = 'Stock unavailable') <> (stock_driver <> ''))
        """).fetchone()[0]
        assert invalid == 0, invalid
        queries = (ROOT / "analysis/kpis.sql").read_text().split(";")
        return [db.execute(query).fetchall() for query in queries if query.strip()]


def render_dashboard(results):
    totals, reasons, stages, drivers, weekly = results
    placed, cancelled, stock, rate, stock_rate, share = totals[0]
    fig = plt.figure(figsize=(15, 10), facecolor="#edf3f8")
    grid = fig.add_gridspec(2, 2, left=.19, right=.94, top=.71, bottom=.13,
                           hspace=.55, wspace=.75)
    ink = "#162a42"
    fig.text(.05, .945, "E-COMMERCE OPERATIONS  /  PORTFOLIO DEMO", color="#08645e", weight="bold", size=12)
    fig.text(.05, .89, "Where marketplace orders cancel", color=ink, weight="bold", size=32)
    fig.text(.05, .85, "Synthetic placed orders  •  Four weekly cohorts  •  One primary reason per cancellation",
             color=ink, size=12)
    cards = ((f"{placed:,}", "Placed orders"), (f"{cancelled}  |  {rate:.1f}%", "All cancellations"),
             (f"{stock}  |  {stock_rate:.1f}%", "Stock cancellations"), (f"{share:.0f}%", "Stock share of cancellations"))
    for index, (value, label) in enumerate(cards):
        x = .05 + index * .235
        fig.text(x, .785, value, color=ink, weight="bold", size=23)
        fig.text(x, .755, label, color=ink, size=11)

    for cell, series, title in ((grid[0, 0], reasons, "01   Primary cancellation reasons"),
                                (grid[0, 1], stages, "02   Stage where issue surfaced"),
                                (grid[1, 0], drivers, "03   Stock-related drivers")):
        ax = fig.add_subplot(cell, facecolor="#edf3f8")
        labels, counts = zip(*series)
        ax.barh(labels, counts, color=["#087e77"] + ["#7292b1"] * (len(counts) - 1), height=.57)
        ax.invert_yaxis()
        ax.set_xlim(0, max(counts) * 1.23)
        for row, count in enumerate(counts):
            ax.text(count + max(counts) * .035, row, str(count), va="center", color=ink, weight="bold")
        ax.set_xticks([])
        ax.tick_params(axis="y", length=0, labelsize=11, colors=ink)
        ax.set_title(title, loc="left", weight="bold", color=ink, pad=10)
        for spine in ax.spines.values():
            spine.set_visible(False)

    ax = fig.add_subplot(grid[1, 1], facecolor="#edf3f8")
    weeks = [row[0] for row in weekly]
    rates = [row[3] for row in weekly]
    ax.plot(weeks, rates, color="#087e77", linewidth=2.5, marker="o")
    ax.axhline(4, color="#8c5665", linestyle="--", linewidth=1.5)
    ax.text(1.07, 4.14, "Illustrative target 4.0%", color="#704350", size=9)
    ax.set_xticks(weeks, [f"Week {week}" for week in weeks])
    ax.set_yticks([0, 2, 4, 6, 8], ["0%", "2%", "4%", "6%", "8%"])
    ax.set_ylim(0, 8.3)
    ax.grid(axis="y", alpha=.2)
    ax.set_title("04   Stock cancellations / placed orders", loc="left", weight="bold", color=ink, pad=10)
    for spine in ax.spines.values():
        spine.set_visible(False)
    fig.text(.05, .055, "Proposed controls   •   Reserve stock at checkout   •   Reconcile seller counts   •   Track refund exceptions",
             color=ink, size=11, weight="bold")
    fig.text(.05, .028, "Demo counts and labels are simulated. Target represents a proposed pilot goal.", color=ink, size=10)
    fig.savefig(ROOT / "assets/demo-analysis.png", dpi=150)
    plt.close(fig)


if __name__ == "__main__":
    orders = build_orders()
    results = run_analysis(orders)
    assert results[0] == [(1000, 120, 60, 12.0, 6.0, 50.0)]
    with (ROOT / "data/orders.csv").open("w", newline="", encoding="utf-8") as output:
        writer = csv.writer(output)
        writer.writerow(FIELDS)
        writer.writerows(orders)
    for result in results:
        print(result)
    render_dashboard(results)
